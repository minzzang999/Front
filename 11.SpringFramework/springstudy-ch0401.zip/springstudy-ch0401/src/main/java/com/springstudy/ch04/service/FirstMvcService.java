package com.springstudy.ch04.service;

public interface FirstMvcService {
	public abstract String getMessage(int no, String id);
}
