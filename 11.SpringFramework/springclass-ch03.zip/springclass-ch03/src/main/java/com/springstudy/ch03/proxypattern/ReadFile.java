package com.springstudy.ch03.proxypattern;

public interface ReadFile {
	public void fileDisplay();
}
